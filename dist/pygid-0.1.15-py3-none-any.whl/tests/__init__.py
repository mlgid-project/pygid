"""
Tests package for pygid.
"""